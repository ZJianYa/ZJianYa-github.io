<template>
    <div>
        <img src="https://secure.gravatar.com/avatar/646c698b580eb0ee44a7e4a55c33aaec?s=128" alt="A picture of Arran">
    </div>
</template>

<style scoped>
img {
    display: block;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
}
</style>
